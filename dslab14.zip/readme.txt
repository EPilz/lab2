We have implemented all stages and features.
The stages have been distributed between the group members as follows: 
Elisabeth Pilz implemented Stage 1 & 3,
Roland Oberweger Stage 2 and 
Romana Jakob implemented Stage 4.
Testing: all
